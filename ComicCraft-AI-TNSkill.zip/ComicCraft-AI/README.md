# ComicCraft - AI Comic Story Creator using Gemini Models

TN Skill project based on the supplied ComicCraft specification.

## Features
- Story prompt, character, setting, tone and art-style inputs
- 5-panel structured comic outline
- Gemini integration point for story generation
- FastAPI + Jinja2 frontend
- Comic preview page
- JSON API endpoint
- Isolated image-generation module for Stable Diffusion integration

## Run
```bash
python -m venv env
# Windows: env\Scripts\activate
# macOS/Linux: source env/bin/activate
pip install -r requirements.txt
uvicorn app.main:app --reload
```

Open http://127.0.0.1:8000 and /docs for API testing.

Create `.env` from `.env.example` and add your Gemini/Hugging Face keys.
