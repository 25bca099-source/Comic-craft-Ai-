def generate_story(outline, character, tone):
    return [{"panel_number":p["panel_number"],"narration":p["scene_description"],
             "dialogue":f"“We can do this!” — {character}"} for p in outline]
