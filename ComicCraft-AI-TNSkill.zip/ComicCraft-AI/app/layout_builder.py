from .image_generator import generate_image
def build_comic_layout(outline, story):
    sm={x["panel_number"]:x for x in story}
    out=[]
    for p in outline:
        s=sm[p["panel_number"]]
        out.append({**p,**s,"image_path":generate_image(p["image_prompt"],f"panel_{p['panel_number']}")})
    return out
