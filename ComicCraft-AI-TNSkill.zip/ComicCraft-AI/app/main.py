from fastapi import FastAPI, Request, Form
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from fastapi.responses import HTMLResponse
from .gemini_flash import generate_outline
from .gemini_pro import generate_story
from .layout_builder import build_comic_layout

app=FastAPI(title="ComicCraft - AI Comic Story Creator")
app.mount("/static", StaticFiles(directory="app/static"), name="static")
templates=Jinja2Templates(directory="app/templates")

@app.get("/", response_class=HTMLResponse)
async def home(request: Request):
    return templates.TemplateResponse("index.html", {"request":request})

@app.post("/generate", response_class=HTMLResponse)
async def generate(request: Request, prompt:str=Form(...), character:str=Form(...),
                   setting:str=Form(...), tone:str=Form(...), art_style:str=Form(...)):
    outline=generate_outline(prompt,character,setting,tone,art_style)
    story=generate_story(outline,character,tone)
    layout=build_comic_layout(outline,story)
    return templates.TemplateResponse("comic_preview.html",{"request":request,"layout":layout})

@app.post("/generate-comic/json")
async def generate_json(payload:dict):
    outline=generate_outline(payload.get("prompt",""),payload.get("character","Hero"),
                             payload.get("setting","Forest"),payload.get("tone","funny"),
                             payload.get("art_style","comic book"))
    story=generate_story(outline,payload.get("character","Hero"),payload.get("tone","funny"))
    return {"layout":build_comic_layout(outline,story)}
