from pathlib import Path
def generate_image(prompt, name):
    p=Path("app/static/panels")/f"{name}.txt"
    p.write_text("Image prompt: "+prompt,encoding="utf-8")
    return "/static/panels/"+p.name
