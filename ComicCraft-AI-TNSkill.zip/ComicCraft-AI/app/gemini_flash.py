import os, json
def generate_outline(prompt, character, setting, tone, art_style):
    if os.getenv("GEMINI_API_KEY"):
        try:
            from google import genai
            c=genai.Client(api_key=os.getenv("GEMINI_API_KEY"))
            q=f"Create exactly 5 comic panels as JSON. Prompt:{prompt}; Character:{character}; Setting:{setting}; Tone:{tone}; Art:{art_style}. Fields: panel_number,title,scene_description,image_prompt."
            text=c.models.generate_content(model=os.getenv("GEMINI_FLASH_MODEL","gemini-2.0-flash"),contents=q).text
            return json.loads(text.replace("```json","").replace("```","").strip())
        except Exception: pass
    return [
      {"panel_number":1,"title":"The Beginning","scene_description":f"{character} starts an adventure in {setting}.","image_prompt":f"{art_style} comic panel of {character} in {setting}"},
      {"panel_number":2,"title":"A Strange Clue","scene_description":"A mysterious clue changes the plan.","image_prompt":f"{art_style} comic panel, mysterious clue, {setting}"},
      {"panel_number":3,"title":"The Challenge","scene_description":f"The {tone} adventure becomes difficult.","image_prompt":f"{art_style} action comic panel, {character}"},
      {"panel_number":4,"title":"The Big Moment","scene_description":"Courage and teamwork solve the challenge.","image_prompt":f"{art_style} heroic comic panel, {character}"},
      {"panel_number":5,"title":"A New Adventure","scene_description":"The story ends with a hopeful hint of what comes next.","image_prompt":f"{art_style} happy ending comic panel"}
    ]
